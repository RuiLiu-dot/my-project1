<template>
<!-- App.vue为顶级组件，components问单文件组件，可复用 -->
  <div id="app">
    <!-- 3：使用组件 -->
    <top />
    <index />
  </div>
</template>

<script>
// 1：导入单文件组件    （还有另外一种自定义组件，使用vue.extend定义，创建模板，注册，在结构中使用将组件作为标签）
import top from '@/components/top';
import index from '@/components/index';
export default {
  name: 'app',
  components: {
    //2：注册组件
    top,
    index
  }
};
</script>

<style lang="scss">

</style>
