<template>
  <div class="index-container">
    <!-- 侧边栏start -->
    <div class="nav" >
      <ul>
        <li>
          <router-link to="/discovery">
            <span class="iconfont icon-find-music"></span>
            发现音乐
          </router-link>
        </li>
        <li>
          <router-link to="/playlists">
            <span class="iconfont icon-music-list"></span>
            推荐歌单
          </router-link>
        </li>
        <li>
          <router-link to="/songs">
            <span class="iconfont icon-music"></span>
            最新音乐
          </router-link>
        </li>
        <li>
          <router-link to="/mvs">
            <span class="iconfont icon-mv"></span>
            最新MV
          </router-link>
        </li>
      </ul>
    </div>
    <div class="main">
      <router-view></router-view>
    </div>
    <!-- 底部播放器start -->
    <div class="player">
      <audio controls autoplay :src="url" loop></audio>
    </div>
  </div>
</template>

<script>
export default {
  name: 'index',
  // data是一个函数，返回值是一个对象，method是一个对象，里面是定义的函数方法
  data() {
    return {
      activeIndex: 0,
      url:""
    };
  }
};
</script>

<style>
 
</style>
