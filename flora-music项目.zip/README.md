# flora-music
> A Vue.js project

## 感谢
https://github.com/sl1673495/vue-netease-music

## 后端接口
网易云api:
https://binaryify.github.io/NeteaseCloudMusicApi

## 技术栈
[vue-cli3](https://cli.vuejs.org/zh/) 创建的项目

[sass](https://cli.vuejs.org/zh/guide/css.html#%E9%A2%84%E5%A4%84%E7%90%86%E5%99%A8)(vue-cli中使用sass)

[Element-ui](https://element.eleme.cn/#/zh-CN/component/quickstart)(轮播，分页，tab切换)

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run serve

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```



